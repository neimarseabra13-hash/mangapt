# MangaPT Cloud

MangaPT é uma interface web para importar páginas autorizadamente acessíveis, fazer OCR, traduzir e renderizar uma versão em português.

## O que esta versão prepara
- Importação de capítulos por URL e imagens locais.
- Proxy de imagens para o leitor.
- OCR real com Tesseract, agrupando palavras em linhas/blocos.
- Pré-processamento de imagem para texto pequeno.
- Tradução individual e em lote.
- Pipeline completo OCR → tradução → renderização.
- Renderização de texto traduzido sobre a região detectada.
- Interface responsiva para celular.
- Docker pronto para hospedagem.
- Configuração do tradutor por variáveis de ambiente.

## Tradução automática
Sem um provedor configurado, o OCR continua funcionando e a interface permite revisão manual.

Para um endpoint compatível com LibreTranslate:
```env
TRANSLATOR_URL=https://seu-endpoint/translate
TRANSLATOR_KEY=seu-token-se-houver
TRANSLATOR_MODE=generic
```

Para um endpoint compatível com OpenAI Chat Completions:
```env
TRANSLATOR_URL=https://seu-provedor/v1/chat/completions
TRANSLATOR_KEY=seu-token
TRANSLATOR_MODE=openai-compatible
TRANSLATOR_MODEL=gpt-4.1-mini
```

O servidor envia o token como `Authorization: Bearer ...`.

## Rodar localmente
```bash
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 10000
```

## Docker
```bash
docker build -t mangapt .
docker run -p 10000:10000 --env-file .env mangapt
```

## Endpoints principais
- `GET /api/health`
- `GET /api/import?url=...`
- `GET /api/image?url=...`
- `POST /api/ocr`
- `POST /api/translate`
- `POST /api/translate/batch`
- `POST /api/process-url`
- `POST /api/process-upload`
- `POST /api/render`

## Segurança
O importador bloqueia endereços locais/privados e não tenta contornar login, CAPTCHA, paywall ou proteções anti-bot. Use apenas conteúdo que você esteja autorizado a acessar e traduzir.
